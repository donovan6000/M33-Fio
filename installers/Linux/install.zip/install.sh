#!/bin/sh

# Request elevated privileges
[ "$(whoami)" != "root" ] && exec sudo -- "$0" "$@"

# Check if not run as root
if [ "$(id -u)" != "0" ]; then

	# Display message
	echo
	echo 'Root privileges required.'
	echo

# Otherwise
else

	# Check if connected to the internet
	wget -q --tries=1 --timeout=5 --spider http://google.com
	if [ $? -eq 0 ]; then
	
		# Move to temporary location
		cd $(dirname $(mktemp -u))
	
		# Set if using OctoPi
		if [ -f /etc/init.d/octoprint ]; then
			usingOctoPi=true
		else
			usingOctoPi=false
		fi
		
		# Check if not using OctoPi
		if ! $usingOctoPi
		then
		
			# Install OctoPrint and M33 Fio dependencies
			apt-get update
			apt-get -y install python python-pip python-dev libyaml-dev build-essential python-pygame libjpeg-dev zlib1g-dev
			sudo -u $SUDO_USER pip install regex --user
			sudo -u $SUDO_USER pip install pillow --user
	
			# Install OctoPrint
			killall -w octoprint
			wget https://github.com/foosel/OctoPrint/archive/master.zip
			sudo -u $SUDO_USER unzip master.zip
			cd OctoPrint-master
			sudo -u $SUDO_USER python setup.py install --user
			cd ..
			sudo -u $SUDO_USER mkdir -p '/home/'"$SUDO_USER"'/.octoprint'
			rm -rf '/home/'"$SUDO_USER"'/.octoprint/checkout'
			sudo -u $SUDO_USER mv OctoPrint-master '/home/'"$SUDO_USER"'/.octoprint/checkout'
			rm master.zip
			
			# Install M33 Fio
			echo 'y' | sudo -u $SUDO_USER pip uninstall OctoPrint-M33Fio
			wget https://github.com/donovan6000/M33-Fio/archive/master.zip
			while ! sudo -u $SUDO_USER pip install master.zip --user
			do
				:
			done
			rm master.zip
		
		# Otherwise
		else
		
			# Install M33 Fio
			echo 'y' | sudo -u pi /home/pi/oprint/bin/pip uninstall OctoPrint-M33Fio
			wget https://github.com/donovan6000/M33-Fio/archive/master.zip
			while ! sudo -u pi /home/pi/oprint/bin/pip install master.zip
			do
				:
			done
			rm master.zip
		fi
	
		# Apply printer udev rule
		wget -O /etc/udev/rules.d/90-micro-3d-local.rules https://raw.githubusercontent.com/donovan6000/M33-Fio/master/installers/Linux/90-micro-3d-local.rules
		
		# Apply heatbed udev rule
		wget -O /etc/udev/rules.d/91-micro-3d-heatbed-local.rules https://raw.githubusercontent.com/donovan6000/M33-Fio/master/installers/Linux/91-micro-3d-heatbed-local.rules
		/etc/init.d/udev restart
		
		# Check if not using OctoPi
		if ! $usingOctoPi
		then
		
			# Add OctoPrint to list of startup commands
			sed -i '/octoprint/d' /etc/rc.local
			sed -i -e '$i \sudo -u '"$SUDO_USER"' "/home/'"$SUDO_USER"'/.local/bin/octoprint"\n' /etc/rc.local
			
			# Create URL link on desktop
			wget https://raw.githubusercontent.com/donovan6000/M33-Fio/master/installers/Linux/octoprint.png
			mv octoprint.png '/usr/share/icons'
			sudo -u $SUDO_USER wget https://raw.githubusercontent.com/donovan6000/M33-Fio/master/installers/Linux/OctoPrint.desktop
			mv OctoPrint.desktop '/home/'"$SUDO_USER"'/Desktop'
			
			# Start OctoPrint
			rm -rf '/home/'"$SUDO_USER"'/.python-eggs'
			sudo -u $SUDO_USER nohup '/home/'"$SUDO_USER"'/.local/bin/octoprint' >/dev/null 2>&1 &
			
			# Display message
			echo 'OctoPrint and M33 Fio have been successfully installed. Go to http://localhost:5000 in any web browser to access OctoPrint.'
			echo
		
		# Otherwise
		else
		
			# Display message
			echo
			echo 'M33 Fio has been successfully installed.'
			echo
		fi
	
	# Otherwise
	else
	
		# Display message
		echo
		echo 'An internet connection is required.'
		echo
	fi
fi
